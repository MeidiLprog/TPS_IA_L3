import itertools, functools


class Sentence():
    def evaluate(self, model):
        """Evaluates the logical sentence."""
        raise Exception("nothing to evaluate")

    def formula(self):
        """Returns string formula representing logical sentence."""
        return ""

    def symbols(self):
        """Returns a set of all symbols in the logical sentence."""
        return set()

    @classmethod
    def validate(cls, sentence):
        if not isinstance(sentence, Sentence):
            raise TypeError("must be a logical sentence")

    @classmethod
    def parenthesize(cls, s):
        """Parenthesizes an expression if not already parenthesized."""
        def balanced(s):
            """Checks if a string has balanced parentheses."""
            count = 0
            for c in s:
                if c == "(":
                    count += 1
                elif c == ")":
                    if count <= 0:
                        return False
                    count -= 1
            return count == 0
        if not len(s) or s.isalpha() or (
            s[0] == "(" and s[-1] == ")" and balanced(s[1:-1])
        ):
            return s
        else:
            return f"({s})"


class Empty(Sentence):

    def __init__(self):
        pass

    def __eq__(self, other):
        return isinstance(other, Empty)

    def __hash__(self):
        return hash(("empty"))

    def __repr__(self):
        return "empty clause"

    def evaluate(self, model):
        return False

    def formula(self):
        return "False"

    

class Symbol(Sentence):
    def __init__(self, name):
        self.name = name

    def __eq__(self, other):
        return isinstance(other, Symbol) and self.name == other.name

    def __lt__(self, other):
        if isinstance(other, Symbol):
            return self.name < other.name
        else:
            return True

    def __hash__(self):
        return hash(("symbol", self.name))

    def __repr__(self):
        return self.name

    def evaluate(self, model):
        try:
            return bool(model[self.name])
        except KeyError:
            raise EvaluationException(f"variable {self.name} not in model")

    def formula(self):
        return self.name

    def symbols(self):
        return {self.name}


class Not(Sentence):
    def __init__(self, operand):
        Sentence.validate(operand)
        self.operand = operand

    def __eq__(self, other):
        return isinstance(other, Not) and self.operand == other.operand

    def __lt__(self, other):
        if isinstance(other, Symbol):
            return False
        elif isinstance(other, Not):
            return self.operand < other.operand
        else:
            return True

    def __hash__(self):
        return hash(("not", hash(self.operand)))

    def __repr__(self):
        return f"Not({self.operand})"

    def evaluate(self, model):
        return not self.operand.evaluate(model)

    def formula(self):
        return "¬" + Sentence.parenthesize(self.operand.formula())

    def symbols(self):
        return self.operand.symbols()


class And(Sentence):
    def __init__(self, *conjuncts):
        for conjunct in conjuncts:
            Sentence.validate(conjunct)
        self.conjuncts = list(conjuncts)

    def __eq__(self, other):
        return isinstance(other, And) and self.conjuncts == other.conjuncts

    def __hash__(self):
        return hash(
            ("and", tuple(hash(conjunct) for conjunct in self.conjuncts))
        )

    def __repr__(self):
        conjunctions = ", ".join(
            [str(conjunct) for conjunct in self.conjuncts]
        )
        return f"And({conjunctions})"

    def add(self, conjunct):
        Sentence.validate(conjunct)
        self.conjuncts.append(conjunct)

    def evaluate(self, model):
        return all(conjunct.evaluate(model) for conjunct in self.conjuncts)

    def formula(self):
        if len(self.conjuncts) == 1:
            return self.conjuncts[0].formula()
        return " ∧ ".join([Sentence.parenthesize(conjunct.formula())
                           for conjunct in self.conjuncts])

    def symbols(self):
        return set.union(*[conjunct.symbols() for conjunct in self.conjuncts])


class Or(Sentence):
    def __init__(self, *disjuncts):
        for disjunct in disjuncts:
            Sentence.validate(disjunct)
        self.disjuncts = list(disjuncts)

    def __eq__(self, other):
        return isinstance(other, Or) and self.disjuncts == other.disjuncts

    def __hash__(self):
        return hash(
            ("or", tuple(hash(disjunct) for disjunct in self.disjuncts))
        )

    def __repr__(self):
        disjuncts = ", ".join([str(disjunct) for disjunct in self.disjuncts])
        return f"Or({disjuncts})"

    def evaluate(self, model):
        return any(disjunct.evaluate(model) for disjunct in self.disjuncts)

    def formula(self):
        if len(self.disjuncts) == 1:
            return self.disjuncts[0].formula()
        return " ∨  ".join([Sentence.parenthesize(disjunct.formula())
                            for disjunct in self.disjuncts])

    def symbols(self):
        return set.union(*[disjunct.symbols() for disjunct in self.disjuncts])


class Implication(Sentence):
    def __init__(self, antecedent, consequent):
        Sentence.validate(antecedent)
        Sentence.validate(consequent)
        self.antecedent = antecedent
        self.consequent = consequent

    def __eq__(self, other):
        return (isinstance(other, Implication)
                and self.antecedent == other.antecedent
                and self.consequent == other.consequent)

    def __hash__(self):
        return hash(("implies", hash(self.antecedent), hash(self.consequent)))

    def __repr__(self):
        return f"Implication({self.antecedent}, {self.consequent})"

    def evaluate(self, model):
        return ((not self.antecedent.evaluate(model))
                or self.consequent.evaluate(model))

    def formula(self):
        antecedent = Sentence.parenthesize(self.antecedent.formula())
        consequent = Sentence.parenthesize(self.consequent.formula())
        return f"{antecedent} => {consequent}"

    def symbols(self):
        return set.union(self.antecedent.symbols(), self.consequent.symbols())


class Biconditional(Sentence):
    def __init__(self, left, right):
        Sentence.validate(left)
        Sentence.validate(right)
        self.left = left
        self.right = right

    def __eq__(self, other):
        return (isinstance(other, Biconditional)
                and self.left == other.left
                and self.right == other.right)

    def __hash__(self):
        return hash(("biconditional", hash(self.left), hash(self.right)))

    def __repr__(self):
        return f"Biconditional({self.left}, {self.right})"

    def evaluate(self, model):
        return ((self.left.evaluate(model)
                 and self.right.evaluate(model))
                or (not self.left.evaluate(model)
                    and not self.right.evaluate(model)))

    def formula(self):
        left = Sentence.parenthesize(str(self.left.formula()))
        right = Sentence.parenthesize(str(self.right.formula()))
        return f"{left} <=> {right}"

    def symbols(self):
        return set.union(self.left.symbols(), self.right.symbols())

def rm_biconditionals(proposition):
    # Cette fonction me permet de supprimer les équivalences simples mais aussi celles imbriqués
    # ainsi que celles imbriqués meme dans des implications
    # je récupère dans l'opérande gauche et droite et je les traite séparemment surtout si elles comportent des équivalences imbriquées
    # Pour le And/Or/Not je fais des listes afin de tout traiter étape par étape

    if(isinstance(proposition,Biconditional)): #UN Biconditional est une équivalence <=> et une équivalence signifie A=>B et B=>A
        gauche = Implication(proposition.left,proposition.right) # Donc ici A=>B
        droit = Implication(proposition.right,proposition.left)  # B=>A
        return And(rm_biconditionals(gauche),rm_biconditionals(droit)) # je renvoie ( (A => B) ∧ (B => A) )
    
    #Ajout en plus des symboles pour traiter des expressions plus difficiles exemple ((A<=>B)∧ C) ou bien (A ∧ Not(B<=>C)) 
    elif(isinstance(proposition,And)):
        return And(*(rm_biconditionals(conjunct) for conjunct in proposition.conjuncts)) # *déballe une liste, et pour chaque proposition, il renvoie ce qu'il faut
                                                                                         # Exemple ici [And((Bonditional(A,B),C)], résultat -> ( (A=>B) ∧ (B=>A) ∧ C )
    elif(isinstance(proposition,Or)):
        return Or(*(rm_biconditionals(disjunct) for disjunct in proposition.disjuncts))
    elif(isinstance(proposition,Not)):
        return Not(rm_biconditionals(proposition.operand)) # operand ici est l'expression interne, exemple: (a∧b) dans Not(a ∧ b) et ajoute le Not
    
    elif(isinstance(proposition,Implication)):
        left = rm_biconditionals(proposition.antecedent)
        right = rm_biconditionals(proposition.consequent)
        return Implication(left, right)
    else:
        return proposition

        

def rm_implications(proposition):
    """Replace implications A=>B with the rule ¬A∨B"""
    
    if(isinstance(proposition,Implication)):
        return Or(Not(rm_implications(proposition.antecedent)),rm_implications(proposition.consequent))
        
    #Ici meme principe que pour la fonction rm_biconditionals, je le fais juste de facon récursive ex: ( (¬A∨B) v (¬B∨A))
    elif(isinstance(proposition,And)):
        return And(*(rm_implications(conjunct) for conjunct in proposition.conjuncts))
    elif(isinstance(proposition,Or)):
        return Or(*(rm_implications(disjunct) for disjunct in proposition.disjuncts))
    elif(isinstance(proposition,Not)):
        return (Not(rm_implications(proposition.operand)))
    elif(isinstance(proposition,Biconditional)):
        gauche = Implication(proposition.left,proposition.right) # Donc ici A=>B
        droit = Implication(proposition.right,proposition.left)  # B=>A
        return And(rm_biconditionals(gauche),rm_biconditionals(droit)) # je renvoie ( (A => B) ∧ (B => A) )

    else:
        return proposition

def mv_not(proposition):
    """Déplacer les négations à l'intérieur avec les règles de De Morgan et supprimer les double négations."""
    
    if isinstance(proposition, Not):
        if isinstance(proposition.operand, Not):
            return mv_not(proposition.operand.operand)
        elif isinstance(proposition.operand, And):
            return Or(*(mv_not(Not(conjunct)) for conjunct in proposition.operand.conjuncts))
        elif isinstance(proposition.operand, Or):
            return And(*(mv_not(Not(disjunct)) for disjunct in proposition.operand.disjuncts))
        else:
            return Not(mv_not(proposition.operand))
    elif isinstance(proposition,Or):
        return Or(*(mv_not(disjunct) for disjunct in proposition.disjuncts))
    elif isinstance(proposition,And):
        return And(*(mv_not(conjunct) for conjunct in proposition.conjuncts))
    else:
        return proposition # Retourne l'original si ce n'est pas un And ou un Or



def flatten(proposition):
    """ flatten proposition, e.g. A∨(B∨C) becomes A∨B∨C"""
    def flatten_And(proposition):
        return(functools.reduce(lambda l,e: l+flatten_And(e) if isinstance(e,And) else l+[flatten(e)], proposition.conjuncts, []))
    
    def flatten_Or(proposition):
        return(functools.reduce(lambda l,e: l+flatten_Or(e) if isinstance(e,Or) else l+[flatten(e)], proposition.disjuncts, []))

    if isinstance(proposition, Not):
        return proposition
    elif isinstance(proposition, And):
        set_and = set(flatten_And(proposition))
        if len(set_and) == 1:
            return list(set_and)[0]
        else:
            return And(*set_and)
    elif isinstance(proposition, Or):
        set_or = set(flatten_Or(proposition))
        if len(set_or) == 1:
            return list(set_or)[0]
        else:
            return Or(*set_or)
    else:
        return proposition


def apply_distribution(proposition):
    """apply distribution laws, e.g. A∨(B∧C) becomes (A∨B)∧(A∨C) """
    if isinstance(proposition, Or):
        disj = proposition.disjuncts
        (ands, others) = functools.reduce(lambda l,e:
                                          (l[0]+[e.conjuncts],l[1]) if isinstance(e,And)
                                          else (l[0],l[1]+e.disjuncts if isinstance(e,Or)
                                                else l[1]+[e]
                                                ), 
                                                disj, ([],[]))
        if ands:
            conj = functools.reduce(lambda l,and_conjuncts: 
                                        functools.reduce(lambda sl, el: 
                                            sl+list(map(lambda conjuct: el+[conjuct], and_conjuncts)),
                                            l, []),
                                        ands, [others])
            return apply_distribution(And(*list(map(lambda e: Or(*e), conj))))
        elif all(isinstance(e, Symbol) or isinstance(e, Not) or isinstance(e,Empty) for e in others):
            return Or(*others)
        else:
            return apply_distribution(Or(*others))
    elif isinstance(proposition, And):
        conj = list(map(lambda e: apply_distribution(e),proposition.conjuncts))
        return And(*conj)
    else:
        # not or litterals
        return proposition
    

def convert_to_CNF(proposition):
    # 1. Éliminer les biconditionnelles
    proposition = rm_biconditionals(proposition)

    # 2. Éliminer les implications
    proposition = rm_implications(proposition)

    # 3. Déplacer les négations
    proposition = mv_not(proposition)

    # 4. Appliquer la distribution
    proposition = apply_distribution(proposition)

    # 5. Aplatir les résultats
    proposition = flatten(proposition)

    return proposition



def resolve(c1,c2):
    """apply resolution inference to two clauses"""
    """e.g. A∨B∨¬C and ¬A∨C becomes [B∨¬C,A∨B∨¬A] """
    """Warning: c1 are c2 assumed to be well-formed clauses"""
    # print("c1="+c1.formula())
    # print("c2="+c2.formula())
    def get_lst(clause):
        lst = []
        if isinstance(clause,Or):
            lst = clause.disjuncts
        elif isinstance(clause,Symbol) or isinstance(clause,Not):
            lst = [clause]
        return lst
    
    kb = []
    l1 = get_lst(c1)
    l2 = get_lst(c2)
    i=0
    while i<len(l1):
        resolution = False
        if isinstance(l1[i],Not):
            if l1[i].operand in l2:
                resolution = True
                new_clause = l1[:i]+l1[i+1:]
                new_clause = new_clause+[e for e in l2 if e != l1[i].operand]
        elif Not(l1[i]) in l2:
            resolution = True
            new_clause = l1[:i]+l1[i+1:]
            new_clause = new_clause+[e for e in l2 if e != Not(l1[i])]
        if resolution:
            # build clause for kb
            if Empty() in new_clause:
                new_clause.remove(Empty())
            new_clause = list(set(new_clause))
            if len(new_clause) == 0:
                kb.append(Empty())
            elif len(new_clause) == 1:
                kb.append(new_clause[0])
            else:
                # order clause to avoid redundant clauses in kb
                kb.append(Or(*sorted(new_clause)))
        i+=1
    # print(kb)
    return kb


def resolution_inference(knowledge, query):
    """Apply inference rules and resolution to prove knowledge base entails query."""
    """Return True if knowledge base entails query; False otherwise"""
    #KB |= alpha donc KB notre base de connaissance, alpha ce que nous devons inférer/entrainer en prouvant la base de connaissance vraie
    #Pour commencer l'on va utiliser la résolution par réfutation, basée sur l'absurde
    #Donc ¬Alpha , l'on va donc utiliser un KB "intermédiaire comme KB'" donc KB' = KB U ¬alpha ,il faut rajouter ¬alpha à notre base de connaissance
    # Et transformer KB en forme normale conjonctive
    # Ensuite pour chaque pair de CLause si j'ai une nouvelle clause je l'ajoute sinon je passe, si rien n'est à ajouter alors impossible d'inférer alpha
    # si une nouvelle clause est calculé alors j'ajoute KB_PRIME SINON si je trouve une clause vide alors je retourne vrai
    
    infer = Not(query)
    conversion = convert_to_CNF(And(knowledge,infer))
    if(isinstance(conversion,And)):
        KB = list(conversion.conjuncts)
    else:
        KB = [conversion]


    while True:
        KB_PRIME = set()

        for i in range(len(KB)):
            for j in range(i+1,len(KB)):
                PREMS_CLAUSE = KB[i]
                DEUX_CLAUSE = KB[j]
                RESULT_RESOLUTION = resolve(PREMS_CLAUSE,DEUX_CLAUSE)
                if RESULT_RESOLUTION:

                    for k in RESULT_RESOLUTION:
                        if(isinstance(k,Empty)):
                            return True
                    if k not in KB and k not in KB_PRIME:
                        KB_PRIME.add(k)
        
        if not KB_PRIME:
            return False
        else:
            KB.extend(KB_PRIME)

def model_check(knowledge, query):
    """Checks if knowledge base entails query."""

    def check_all(knowledge, query, symbols, model):
        """Checks if knowledge base entails query, given a particular model."""

        # If model has an assignment for each symbol
        if not symbols:

            # If knowledge base is true in model, then query must also be true
            if knowledge.evaluate(model):
                return query.evaluate(model)
            return True
        else:

            # Choose one of the remaining unused symbols
            remaining = symbols.copy()
            p = remaining.pop()

            # Create a model where the symbol is true
            model_true = model.copy()
            model_true[p] = True

            # Create a model where the symbol is false
            model_false = model.copy()
            model_false[p] = False

            # Ensure entailment holds in both models
            return (check_all(knowledge, query, remaining, model_true) and
                    check_all(knowledge, query, remaining, model_false))

    # Get all symbols in both knowledge and query
    symbols = set.union(knowledge.symbols(), query.symbols())

    # Check that knowledge entails query
    return check_all(knowledge, query, symbols, dict())

