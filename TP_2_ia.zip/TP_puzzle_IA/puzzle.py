from logic import *
import argparse

AChevalier = Symbol("A est un chevalier")
AValet = Symbol("A est un valet")

BChevalier = Symbol("B est un chevalier")
BValet = Symbol("B est un valet")

CChevalier = Symbol("C est un chevalier")
CValet = Symbol("C est un valet")

# Énigme 0
# A dit "Je suis à la fois un chevalier et un valet."
knowledge0 = And(
    Biconditional(AChevalier,Not(AValet)),
    And(Implication(AChevalier,And(AChevalier,AValet)),
        Implication(AValet,Not(And(AChevalier,AValet)))
        )
)

# Énigme 1
# A dit "Nous sommes tous les deux des chevaliers."
# B ne dit rien.
knowledge1 = And(
    Biconditional(AChevalier,Not(AValet)),
    Biconditional(BChevalier,Not(BValet)),
    And(Implication(AChevalier,And(AChevalier,BChevalier)),
        Implication(AValet,Not(And(AChevalier,BChevalier)))
        )

)

# Énigme 2
# A dit "Nous sommes du même type."
# B dit "Nous sommes d'un type différent."
knowledge2 = And(
    Biconditional(AChevalier,Not(AValet)),
    Biconditional(BChevalier,Not(BValet)),
        
    And(
        Implication(AChevalier,Or(And(AChevalier,BChevalier),And(AValet,BValet))),
        Implication(AValet, Not(Or(And(AChevalier,BChevalier),And(AValet,BValet)))  )  
    ),
    And(
        Implication(BChevalier, Or(And(AChevalier, BValet), And(BChevalier,AValet))),
        Implication(BValet, Not(Or(And(AChevalier,BValet),  And(BChevalier,AValet))))
)

)




# Énigme 3
# A dit parfois "Je suis un chevalier" ou "Je sssuis un valet.", mais on ne sait pas qui il est.
# B dit "A dit : 'Je suis un valet'."
# B dit "C est un valet."
# C dit "A est un chevalier."
knowledge3 = And(
    
    Biconditional(AChevalier,Not(AValet)),
    Biconditional(BChevalier,Not(BValet)),
    Biconditional(CChevalier,Not(CValet)),

     

    And(
        Implication(AChevalier,Or(AChevalier,AValet)),
        Implication(AValet,Not(Or(AChevalier,AValet))),
        #Implication(AValet,Not(AChevalier))
    ),
    And(

        And(
            Implication(BChevalier,AValet),
            Implication(BChevalier,CValet),
            Implication(BValet,Not(CValet)),
        ),
        And(
            Implication(CChevalier,AChevalier),
            Implication(CValet,Not(AChevalier))
        ),

    ),
)



def main(args):
    def check(knowledge, symbol, args):
        if args.r:
            return resolution_inference(knowledge, symbol)
        else:
            return model_check(knowledge, symbol)

    symbols = [AChevalier, AValet, BChevalier, BValet, CChevalier, CValet]
    puzzles = [
        ("Enigme 0", knowledge0),
        ("Enigme 1", knowledge1),
        ("Enigme 2", knowledge2),
        ("Enigme 3", knowledge3)
    ]
    for puzzle, knowledge in puzzles:
        print(puzzle)
        if len(knowledge.conjuncts) == 0:
            print("    Not yet implemented.")
        else:
            for symbol in symbols:
                if check(knowledge, symbol, args):
                    print(f"    {symbol}")


if __name__ == "__main__":
    
    parser = argparse.ArgumentParser(description='Search a solution for clue.')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('-c','--model-check',
                        dest='d', action='store_true',
                        help="use model checking [default]")
    group.add_argument('-r','--resolution',
                        dest="r", action="store_true",
                        help="use resolution for inference")
    parser.set_defaults(type='d')
    args = parser.parse_args()
    main(args)
