from logic import *
# Création de la proposition biconditionnelle
prop1 = Biconditional(Symbol("B1"), Or(Symbol("P1"), Symbol("P2")))

# Affichage de la formule originale
print("Formule originale :")
print(prop1.formula())  # (B1) <=> ((P1) ∨ (P2))

# Étape 1 : Remplacer les biconditionnelles par des implications
step1 = rm_biconditionals(prop1)
print("\nAprès remplacement des biconditionnelles :")
print(step1.formula())  # ((B1 => (P1 ∨ P2)) ∧ ((P1 ∨ P2) => B1))

# Étape 2 : Remplacer les implications par des disjonctions
step2 = rm_implications(step1)
print("\nAprès remplacement des implications :")
print(step2.formula())  # (¬B1 ∨ (P1 ∨ P2)) ∧ (¬(P1 ∨ P2) ∨ B1)

# Étape 3 : Déplacer les négations à l'intérieur
step3 = mv_not(step2)
print("\nAprès déplacement des négations :")
print(step3.formula())  # (¬B1 ∨ (P1 ∨ P2)) ∧ (B1 ∨ (¬P1 ∧ ¬P2))

# Étape 4 : Appliquer la distribution (si nécessaire)
final_cnf = apply_distribution(step3)
print("\nAprès application des lois de distribution :")
print(final_cnf.formula())  # ((¬B1 ∨ P1) ∧ (¬B1 ∨ P2) ∧ (B1 ∨ ¬P1) ∧ (B1 ∨ ¬P2))

final_cnf = flatten(step3)
print("\nAprès application des lois de distribution :")
print(final_cnf.formula())  

# Étape finale : Affichage de la forme normale conjonctive (CNF)
print("\nForme normale conjonctive finale :")
print(final_cnf.formula())
