#LEFKI MEIDI
#L3 INFG2

import torch.nn as nn
import torch.nn.functional as F

# Exercice 6 : Configuration du modèle convolutif (CNN)
"""
L'on peut ajouter des couches convolutives ou augmenter le nombre de canaux dans chaque couche. 
Intégrer la normalisation par lot afin de  stabiliser l'entraînement. 
Ajouter d'avantage de données.

"""
class CnnGrayscaleModel(nn.Module):
    def __init__(self, nbr_classes, dimension, channels):
        super(CnnGrayscaleModel, self).__init__()

        self.dim = dimension
        self.channels = channels

        # 1ère couche de convolution : Entrée 1 canal, Sortie 8 canaux
        self.conv1 = nn.Conv2d(channels, 8, kernel_size=3, stride=1, padding=1)
        
        # Pooling après la 1ère convolution
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        
        # 2ème couche de convolution : Entrée 8 canaux, Sortie 16 canaux
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, stride=1, padding=1)
        
        # Pooling après la 2ème convolution
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        
        # Couche de classification
        # La taille d'entrée est déterminée par : (16 * (dimension/4) * (dimension/4))
        self.fc_classification = nn.Linear(16 * (dimension // 4) * (dimension // 4), nbr_classes)

    def forward(self, x):
        # 1ère couche de convolution
        x = self.conv1(x)
        # Activation ReLU après la 1ère couche de convolution
        x = F.relu(x)
        # Pooling après la 1ère couche de convolution
        x = self.pool1(x)
        
        # 2ème couche de convolution
        x = self.conv2(x)
        # Activation ReLU après la 2ème couche de convolution
        x = F.relu(x)
        # Pooling après la 2ème couche de convolution
        x = self.pool2(x)
        
        # Mise à plat (flatten) des sorties de la couche convolutive pour la classification
        x = x.reshape(x.shape[0], -1)

        # Couche de classification (couche de sortie avec le nombre de classes que nous souhaitons classifier)
        x = self.fc_classification(x)
        
        return x
