#LEFKI MEIDI
#L3 INFG2

import torch.nn as nn
import torch.nn.functional as F

# Exercice 5 : Configuration du modèle perceptron multi-couches (MLP)

"""

Que pouvons-nous changer pour que le modèle soit plus performant ?
L'on peut ajouter des couches cachées ou augmenter le nombre de neurones par couche
L'on peut ajuster notre learning rate.

"""
class MlpGrayscaleModel(nn.Module):
    def __init__(self, nbr_classes, dimension, channels):
        super(MlpGrayscaleModel, self).__init__()

        self.dim = dimension
        self.channels = channels

        # Couche d'entrée prenant en entrée IMG_SIZE x IMG_SIZE x Number of channels et sortant 128 neurones
        self.fc1 = nn.Linear(dimension * dimension * channels, 128)
        # Couche intermédiaire prenant en entrée 128 neurones et sortant 256 neurones
        self.fc2 = nn.Linear(128, 256)
        # Couche de classification (couche de sortie) prenant en entrée 256 neurones et sortant nbr_classes
        self.fc_classification = nn.Linear(256, nbr_classes)
        # Dropout pour régularisation
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        # Mise à plat de l'entrée
        x = x.view(-1, self.dim * self.dim * self.channels)

        # Couche d'entrée avec activation ReLU et Dropout
        x = self.fc1(x)
        x = F.relu(x)  # Corrected function name
        x = self.dropout(x)

        # Couche intermédiaire avec activation ReLU et Dropout
        x = self.fc2(x)
        x = F.relu(x)
        x = self.dropout(x)

        # Couche de classification
        x = self.fc_classification(x)

        return x
