#LEFKI MEIDI
#L3 INFG2

import os
import random
import argparse

import torch
from tqdm import tqdm
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import matplotlib.pyplot as plt
from torchvision import datasets
from torchvision.transforms import v2
from sklearn.metrics import ConfusionMatrixDisplay
from torch.utils.data import DataLoader, random_split

from CnnGrayscaleModel import CnnGrayscaleModel
from MlpGrayscaleModel import MlpGrayscaleModel


def set_seeds(seed):
    """
    Exercice 1 : Implémenter la fonction pour fixer les seeds de random et torch
    Args:
        seed (int): Seed value for random number generators
    """
    # TODO: Implement seed setting for reproducibility
    torch.manual_seed(seed);
    random.seed(seed)




"""

1. En observant manuellement les données, pouvez-vous dire pourquoi il est intéressant de conver-
tir les images en niveaux de gris ?

Réponse: La couleur ici n'est pas pertinente car les car rayons x des scanners produisent des images dont les variations de
luminosité sont plus importantes que les couleurs, l'on a donc plus de facilité à traiter les informations moins de pertes

2. Quel est l’impact du redimensionnement des images sur les performances et la vitesse de
traitement du modèle ?

Réponse: Permet d'améliorer la vitesse de calcul et de correspondre à la dimension pour traiter les CNN correctement
si l'image est trop grande, le temps de calcul risque d'augmenter, si elle est trop petite, il risque d'y avoir des pertes d'information

3. Pourquoi appliquons-nous ce type de normalisation sur les données ?

Réponse: Nous appliquons la normalisation pour permettre à notre modèle de corriger ses poids avec la descente de gradient.
En effet, si nos entrées(valeur du pixel) est trop grande, la fonction g convergera vers 1, si tel est le cas, cela signifie que le graduit lui: Gradient : DELTA(Perte) / DELTA(poids) -> convergera vers 0
si c'est le cas, le modèle apprendra moins vite, car les poids ne seront presque plus mis à jour.


"""

def prepare_dataset(img_size, seed):
    """
    Exercice 2 : Ajouter les transformations nécessaires pour le dataset
    Args:
        img_size (int): Target size for image resizing
        seed (int): Random seed for reproducibility
    Returns:
        tuple: (dataset, ordered_classes) containing the prepared dataset and class names
    """
    dataset = datasets.ImageFolder(
        root="./train_ct_scan",
        transform=v2.Compose([
            v2.Resize(size=(img_size,img_size)),
            v2.Grayscale(1),
            # TODO: Add necessary transforms 
           
            v2.ToImage(),
            v2.ToDtype(torch.float32, scale=True) # convert images to tensors, data structures used as entries by pytorch
        ])
    )
    
    idx_to_classes = {dataset.class_to_idx[name]: name for name in dataset.class_to_idx}
    ordered_classes = [idx_to_classes[idx] for idx in sorted(idx_to_classes.keys())]
    
    return dataset, ordered_classes

"""

1. Pourquoi diviser les données (dataset) en ensembles d’entraînement et de validation ?

    -Réponse: diviser l'ensemble des données en dataset(batch) permet d'entrainer le modèle sur un sous-ensemble de notre ensemble originel
    De plus, cela permet de l'entrainer pour un "set" précis et surtout cela permet d'éviter mais surtout de détecter le surapprentissage et sa capacité à généraliser

2. Que se passerait-il avec un ratio 50/50 ? 90/10 ?

    -Réponse: avec un ratio de 50/50 le modèle s'entraine sur un bon nombre de données mais avec le ratio de 50 de validation, cela risque d'etre assez faible.
    Et pour de 90/10, le modèle est bien entrainé, mais le 10 ne risque pas de données assez de bons résultats sur un batch si petit  

3. Pourquoi est-il important de mélanger (shuffle) les données d’entraînement ?
    
    -Réponse: Cela permet au modèle d'apprendre à mémoriser des motifs plutot qu'un ordre si les données sont ordonnées. De plus chaque batch

"""



def create_data_loaders(dataset, batch_size, seed):
    """
    Exercice 3 : Définir le ratio train/validation approprié
    """
    # TODO: Define train_size ratio
    train_size = int(0.8*len(dataset))
    validation_size = len(dataset) - train_size
    train_set, validation_set = random_split(
        dataset,
        [train_size, validation_size],
        generator=torch.Generator().manual_seed(seed)
    )
    
    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    validation_loader = DataLoader(validation_set, batch_size=batch_size, shuffle=False)

    return train_loader, validation_loader

def parse_arguments():
    """
    Exercice 4 : Configurer les valeurs par défaut appropriées pour l'entraînement
    """
    parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--setup", type=str, required=True, help="Choose the method to run MLP or CNN")
    parser.add_argument("--lr", type=float, required=False, default=1e-4, help="Learning rate")
    parser.add_argument("--epochs", type=int, required=False, default=10, help="Number of epochs")
    parser.add_argument("--batch_size", type=int, required=False, default=32, help="Number data sample per batch")
    return vars(parser.parse_args())


def setup_model(setup_type, img_size, device):
    """
    Initialize either MLP or CNN model based on setup type.
    Args:
        setup_type (str): "MLP" or "CNN"
        img_size (int): Input image dimension
        device (str): Computing device ('cpu' or 'cuda')
    Returns:
        torch.nn.Module: Initialized model
    """
    model_class = MlpGrayscaleModel if setup_type == "MLP" else CnnGrayscaleModel
    model = model_class(nbr_classes=4, dimension=img_size, channels=1).to(device)
    
    total_params = sum(p.numel() for p in model.parameters())
    print(f"{total_params} total parameters.")
    
    return model

def setup_training(model, learning_rate):
    """
    Configure training parameters and loss function.
    Args:
        model: Neural network model
        learning_rate (float): Learning rate for optimizer
    Returns:
        tuple: (optimizer, criterion)
    """
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)
    criterion = nn.CrossEntropyLoss()
    return optimizer, criterion


"""

Comment interpréter les scores de justesse ?
Si l'accuracy d'entraînement augmente mais celle de validation diminue, Alors cela signifie un surapprentissage. 
Le modèle mémorise les données d'entraînement mais ne généralise pas bien sur des données inconnues.

Pourquoi certaines classes ont-elles de meilleures performances ?
Les classes avec plus de données sont mieux apprises. 
Les classes ayant des caractéristiques distinctes sont plus faciles à distinguer. 
En revanche, des classes avec des données similaires ou sous-représentées entraînent des erreurs.

"""


def train(model, trainloader, optimizer, criterion):
    """
    Exercice 7 : Implémenter le calcul du score de justesse
    Args:
        model: Neural network model
        trainloader: DataLoader for training data
        optimizer: Optimization algorithm
        criterion: Loss function
    Returns:
        tuple: (epoch_loss, epoch_accuracy)
    """
    model.train()
    print("--- Training ---")
    
    train_running_loss = 0.0
    train_running_correct = 0
    counter = 0

    for i, data in tqdm(enumerate(trainloader), total=len(trainloader)):
        counter += 1
        image, labels = data
        image = image.to(DEVICE)
        labels = labels.to(DEVICE)
        optimizer.zero_grad()

        # forward pass
        outputs = model(image)

        # calculate the loss
        loss = criterion(outputs, labels)
        train_running_loss += loss.item()

        # TODO: Calculate accuracy
        data = outputs.data
        _, preds = torch.max(outputs, 1)
        train_running_correct += (preds == labels).sum().item()

        # backpropagation
        loss.backward()

        # update the optimizer parameters
        optimizer.step()

    # loss and accuracy for the complete epoch
    epoch_loss = train_running_loss / counter
    epoch_acc = train_running_correct / len(trainloader.dataset)

    return epoch_loss, epoch_acc

def validate(model, validation_loader, criterion, is_last_epoch, setup, class_names):
    """
    Exercice 7 : Implémenter le calcul du score de justesse (accuracy)

    Args:
        model: Neural network model
        validation_loader: DataLoader for validation data
        criterion: Loss function
        is_last_epoch (bool): Whether this is the final epoch
        setup (str): Model type ("MLP" or "CNN")
        class_names (list): ordered class names
    Returns:
        tuple: (epoch_loss, epoch_accuracy)
    """
    model.eval()  # Mettre le modèle en mode évaluation
    print("--- Validation ---")
    
    valid_running_loss = 0.0
    valid_running_correct = 0
    counter = 0

    all_labels = []
    all_preds = []

    with torch.no_grad():  # Pas de calcul des gradients
        for i, data in tqdm(enumerate(validation_loader), total=len(validation_loader)):
            counter += 1
            
            image, labels = data
            image = image.to(DEVICE)
            labels = labels.to(DEVICE)

            outputs = model(image)
            loss = criterion(outputs, labels)
            valid_running_loss += loss.item()
            
            # Calcul de la justesse (accuracy)
            _, preds = torch.max(outputs, 1)
            valid_running_correct += (preds == labels).sum().item()
            all_labels.extend(labels.cpu().numpy())
            all_preds.extend(preds.cpu().numpy())
            
    if is_last_epoch:
        disp = ConfusionMatrixDisplay.from_predictions(
            all_labels, all_preds
        )
        disp.plot()
        os.makedirs("./plots", exist_ok=True)
        plt.savefig(f"./plots/confusion_matrix_{setup}.png")
        print('Confusion matrix saved with the following labels: ')
        print('\t'+(', '.join(list(map(lambda x, y: str(x) + ': ' + y, list(range(len(class_names))), class_names)))))

    epoch_loss = valid_running_loss / counter
    epoch_acc = valid_running_correct / len(validation_loader.dataset)
    return epoch_loss, epoch_acc

"""

Que signifie une courbe de perte qui stagne ?
Une perte stagnante signifie que le modèle a atteint son "seuil" d'apprentissage.
Cela peut être dû à un learning rate trop faible.

Quelles sont les caractéristiques d'un bon entraînement ?
La perte d'entraînement diminue régulièrement et celle de validation suit une tendance similaire.
L'accuracy d'entraînement et de validation sont proches, sans écart important, indiquant peu de surapprentissage.

"""

def plot_metrics(train_acc, valid_acc, train_loss, valid_loss, setup):
    """
    Exercice 8: Implémenter la visualisation des métriques

    Args:
        train_acc (list): Training accuracy history
        valid_acc (list): Validation accuracy history
        train_loss (list): Training loss history
        valid_loss (list): Validation loss history
        setup (str): Model type ("MLP" or "CNN")
    """
    os.makedirs("./plots", exist_ok=True)

    # Visualisation de la précision
    plt.figure()
    plt.plot(train_acc, label="Training Accuracy")
    plt.plot(valid_acc, label="Validation Accuracy")
    plt.xlabel("Epochs")
    plt.ylabel("Accuracy")
    plt.title("Accuracy over Epochs")
    plt.legend()
    plt.savefig(f"./plots/accuracy_{setup}.png")

    # Visualisation de la perte
    plt.figure()
    plt.plot(train_loss, label="Training Loss")
    plt.plot(valid_loss, label="Validation Loss")
    plt.xlabel("Epochs")
    plt.ylabel("Loss")
    plt.title("Loss over Epochs")
    plt.legend()
    plt.savefig(f"./plots/loss_{setup}.png")



if __name__ == "__main__":
    args = parse_arguments()

    DEVICE = 'cpu'
    IMG_SIZE = 512
    EPOCHS = args["epochs"]
    BATCH_SIZE = args["batch_size"]
    LEARNING_RATE = args["lr"]
    SEED = 42

    set_seeds(SEED)

    dataset, ordered_classes = prepare_dataset(IMG_SIZE, SEED)
    train_loader, validation_loader = create_data_loaders(dataset, BATCH_SIZE, SEED)

    model = setup_model(args["setup"], IMG_SIZE, DEVICE)
    optimizer, criterion = setup_training(model, LEARNING_RATE)

    train_loss, valid_loss = [], []
    train_acc, valid_acc = [], []

    for epoch in range(EPOCHS):
        print(f"[INFO]: Epoch {epoch+1} of {EPOCHS}")
        
        train_epoch_loss, train_epoch_acc = train(model, train_loader, optimizer, criterion)
        train_loss.append(train_epoch_loss)
        train_acc.append(train_epoch_acc)
        
        valid_epoch_loss, valid_epoch_acc = validate(model, validation_loader, criterion, epoch+1 == EPOCHS, args["setup"], ordered_classes)
        valid_loss.append(valid_epoch_loss)
        valid_acc.append(valid_epoch_acc)

        print(f"[LOGS]: Training loss: {train_epoch_loss:.3f}, training acc: {train_epoch_acc:.3f}")
        print(f"[LOGS]: Validation loss: {valid_epoch_loss:.3f}, validation acc: {valid_epoch_acc:.3f}")
        print("*"*50)
    
    plot_metrics(train_acc, valid_acc, train_loss, valid_loss, args["setup"])